package com.denali.rfid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RfidTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RfidTrackerApplication.class, args);
	}
}
